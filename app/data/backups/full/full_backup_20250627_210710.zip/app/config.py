import os
import secrets

class Config:
    SECRET_KEY = secrets.token_hex(32)
    DEBUG = os.environ.get('FLASK_ENV') != 'production'  # Disable debug in production

    # Database configuration - use relative paths or memory for Vercel
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///:memory:'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    DATA_DIR = 'data'

    # Disable scheduler for serverless deployment (can be overridden by env var)
    SCHEDULER_ENABLED = os.environ.get('SCHEDULER_ENABLED', 'false').lower() == 'true'

    # Use relative paths for data files
    PPM_JSON_PATH = os.path.join('app', 'data', 'ppm.json')
    OCM_JSON_PATH = os.path.join('app', 'data', 'ocm.json')
    TRAINING_JSON_PATH = os.path.join('app', 'data', 'training.json')
    SETTINGS_JSON_PATH = os.path.join('app', 'data', 'settings.json')
    AUDIT_LOG_JSON_PATH = os.path.join('app', 'data', 'audit_log.json')
    PUSH_SUBSCRIPTIONS_JSON_PATH = os.path.join('app', 'data', 'push_subscriptions.json')

    # Session Configuration - use filesystem for development, secure cookies for production
    SESSION_TYPE = 'filesystem'  # Use filesystem for development
    SESSION_PERMANENT = False  # Don't use permanent sessions in serverless
    SESSION_USE_SIGNER = True  # Sign the session cookie for extra security
    SESSION_COOKIE_SECURE = False  # Use secure cookies only in production
    SESSION_COOKIE_HTTPONLY = True  # Prevent XSS
    SESSION_COOKIE_SAMESITE = 'Lax'  # CSRF protection



