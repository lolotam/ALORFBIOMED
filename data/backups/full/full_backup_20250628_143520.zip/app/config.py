import os
import secrets

class Config:
    SECRET_KEY = secrets.token_hex(32)
    DEBUG = os.environ.get('FLASK_ENV') != 'production'  # Disable debug in production

    # Database configuration - use relative paths or memory for Vercel
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///:memory:'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    DATA_DIR = 'data'

    # Disable scheduler for serverless deployment (can be overridden by env var)
    SCHEDULER_ENABLED = os.environ.get('SCHEDULER_ENABLED', 'false').lower() == 'true'

    # Use relative paths for data files
    PPM_JSON_PATH = os.path.join('app', 'data', 'ppm.json')
    OCM_JSON_PATH = os.path.join('app', 'data', 'ocm.json')
    TRAINING_JSON_PATH = os.path.join('app', 'data', 'training.json')
    SETTINGS_JSON_PATH = os.path.join('app', 'data', 'settings.json')
    AUDIT_LOG_JSON_PATH = os.path.join('app', 'data', 'audit_log.json')
    PUSH_SUBSCRIPTIONS_JSON_PATH = os.path.join('app', 'data', 'push_subscriptions.json')

    # Session Configuration - use filesystem for development, secure cookies for production
    SESSION_TYPE = 'filesystem'  # Use filesystem for development
    SESSION_PERMANENT = False  # Don't use permanent sessions in serverless
    SESSION_USE_SIGNER = True  # Sign the session cookie for extra security
    SESSION_COOKIE_SECURE = False  # Use secure cookies only in production
    SESSION_COOKIE_HTTPONLY = True  # Prevent XSS
    SESSION_COOKIE_SAMESITE = 'Lax'  # CSRF protection

    # Reminder system configuration
    REMINDER_DAYS = 60  # Default days ahead to check for maintenance

    # Email configuration
    MAIL_SERVER = os.environ.get('MAIL_SERVER', 'smtp.gmail.com')
    MAIL_PORT = int(os.environ.get('MAIL_PORT', 587))
    MAIL_USE_TLS = os.environ.get('MAIL_USE_TLS', 'true').lower() == 'true'
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME', 'your-email@gmail.com')
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD', 'your-16-digit-app-password')
    MAIL_DEFAULT_SENDER = os.environ.get('MAIL_DEFAULT_SENDER')

    # Push notification configuration  
    VAPID_PRIVATE_KEY = os.environ.get('VAPID_PRIVATE_KEY')
    VAPID_PUBLIC_KEY = os.environ.get('VAPID_PUBLIC_KEY')
    VAPID_SUBJECT = os.environ.get('VAPID_SUBJECT', 'mailto:dr.vet.waledmohamed@gmail.com')

    # Mailjet Email API configuration (primary email service)
    MAILJET_API_KEY = os.environ.get('MAILJET_API_KEY')
    MAILJET_SECRET_KEY = os.environ.get('MAILJET_SECRET_KEY')
    EMAIL_SENDER = os.environ.get('EMAIL_SENDER', 'dr.vet.waledmohamed@gmail.com')
    EMAIL_RECEIVER = os.environ.get('EMAIL_RECEIVER', 'alorfbiomed@gmail.com')



